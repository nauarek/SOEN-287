<div class="footer">
        <footer><a href="privacy-disclaimer.html" class="special-link">Privacy/Disclaimer Statement</a>Designed for Chrome 2022</footer>
        </div>