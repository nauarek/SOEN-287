<div class="sidebar">
        <a href="homepage.php">Home Page</a>
        <a href="dog-cat.php">Find a Dog/Cat</a>
        <a href="dog-care.php">Dog Care</a>
        <a href="cat-care.php">Cat Care</a>
        <a href ="create-account.php">Create an account</a>
        <a href="give-pet.php">Have a pet to give away?</a>
        <a href="contact-us.php">Contact Us</a>
        <a href="logout.php">Logout </a>
      </div>