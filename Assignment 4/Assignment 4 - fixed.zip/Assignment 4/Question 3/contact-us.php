<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <?php include 'header.php' ?>
    <?php include 'sidebar.php' ?>
      <div class="content-area">
        <h1 class="center">Contact Us</h1><br><br>
        <h2>Name: Nauar Rekmani</h2>
        <h2>Student ID: 40224315</h2>
        <h2>Email: n_rekman@live.concordia.ca</h2>
      </div>
       
    <?php include 'footer.php' ?>
    
</body>
</html>