The files can be found in:
https://users.encs.concordia.ca/~n_rekman/

Question 1 is called: Exercise1.php

Question 2 is called: numOfVisits.php

Question 3 is the website, the index is: homepage.php

For the website the admin account is:

username = admin
password = Admin1

the default pets are as follows

1:admin:dog:Husky:Below 3 years:Male:yes:no:yes:Amanda:Beronilla:amandaberonilla@gmail.com
2:admin:dog:Chihuahua:3-8 years:Female:no:no:no:Abdur:Gigani:argigani24@gmail.com
3:admin:cat:Maine Coon:3-8 years:Female:yes:no:yes:Enam:Adib:enamadib@gmail.com

The file for the users is: users.txt
The file for the pets is: available-pet-information.txt

I have made both of these readable so that you may review
that the writing process works

Thank you,
Nauar Rekmani
40224315